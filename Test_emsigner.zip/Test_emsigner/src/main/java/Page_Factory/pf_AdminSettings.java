package Page_Factory;

import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Generic_Library.Utility;

public class pf_AdminSettings extends pf_genericmethods {
	final static Logger log = Logger.getLogger(pf_AdminSettings.class);

	@FindBy(how = How.XPATH, using = "//i[@class='fa fa-user icon-xs icon-rounded']") public WebElement username;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Settings']") public WebElement settings;
	
	
	//Manage Department
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmappSettings\"]/div/div[7]/div[2]/a") public WebElement manageDept;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"main-content\"]/section/form/div[5]/section/header/div/a") public WebElement createNewDept; 
	
	@FindBy(how = How.ID, using = "btnSaveDepartment") public WebElement saveBtn;
	@FindBy(how = How.XPATH, using = "//div[text()='Department Name is required.']") public WebElement withoutDeptSaveBtn;
	@FindBy(how = How.ID, using = "btncancel") public WebElement cancelBtn;
	@FindBy(how = How.ID, using = "txtDeptName") public WebElement txtDeptName;
	//success msg when dept is created
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'You are Done')]") public WebElement deptCreatedMsg;
	//ok button
	@FindBy(how = How.ID, using = "btnmsgok") WebElement okBtn;
	
	@FindBy(how = How.ID, using = "btnSaveAccess") WebElement WFsaveBtn;
	//without selecting workflow,click on save button
	@FindBy(how = How.XPATH, using = "//div[text()='Please select WorkFlow']") public WebElement withoutWFSaveBtn;
	
	@FindAll({@FindBy(how = How.XPATH, using = "//*[@id=\"jstree\"]")}) public List <WebElement> WFSearchList;
	
	public pf_AdminSettings(WebDriver driver){

		PageFactory.initElements(driver, this);
	}

	public void settings() throws Exception {
		cl_click(username);
		cl_click(settings);
		Thread.sleep(1000);
		
	}

	public void manageDeptcnclBtn(String scriptname, String sheetName) throws Exception {
		cl_click(manageDept);
		Thread.sleep(1000);
		cl_click(createNewDept);
		cl_click(cancelBtn);
		String url=w.getCurrentUrl();
		log.info("URL found when cancel button is clicked: "+url);
		Utility.comparelogic(url,sheetName,scriptname);
		
	}

	public void saveBtnWithoutDept(String scriptname, String sheetName) throws Exception {
		cl_click(createNewDept);
		cl_click(saveBtn);
		String msg=withoutDeptSaveBtn.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);
		String deptName=Utility.getpropertydetails("ManageDepartmentName");
		cl_entertext(txtDeptName, deptName);
		cl_click(saveBtn);
		String exp="You are Done! New Department "+deptName+" successfully created";
		System.out.println("Manage Department creation message: "+exp);
		cl_click(okBtn);
		Thread.sleep(2000);
		
	}

	public void saveBtnWithoutWF(String scriptname, String sheetName) throws Exception {
		cl_click(WFsaveBtn);
		Thread.sleep(1000);
		String msg=withoutWFSaveBtn.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);
		Thread.sleep(3000);
		Random r = new Random();
		int randomValue = r.nextInt(WFSearchList.size());
		System.out.println("randomValue" +randomValue);
		WFSearchList.get(randomValue).click();
		Thread.sleep(2000);
		cl_click(WFsaveBtn);
		Thread.sleep(2000);
				
		
		
	}
}
