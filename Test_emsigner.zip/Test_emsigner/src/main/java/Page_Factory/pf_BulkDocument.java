package Page_Factory;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import Generic_Library.Basefunctions;
import Generic_Library.Utility;

public class pf_BulkDocument extends pf_genericmethods {
	final static Logger log = Logger.getLogger(pf_BulkDocument.class);


	@FindBy(how = How.ID, using = "Offline") WebElement bulkDoc;

	@FindBy(how = How.ID, using = "btncontinue") WebElement continuebutton;

	@FindBy(how = How.ID, using = "btnpdfupload") WebElement createTempbutton;
	@FindBy(how = How.XPATH, using = "//div[@class='info']") WebElement continueMsg;
	//message while uploading doc other than pdf
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'NOTE:Only .PDF document(s)')]") WebElement uploadMessage;
	@FindBy(how = How.ID, using = "btnmsgok") WebElement okBtn;
	//check progress bar
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Preparing your document for')]") WebElement progressMsg;
	//save button
	@FindBy(how = How.ID, using = "btnSave") WebElement saveBtn;
	@FindBy(how = How.XPATH, using ="//div[contains(text(),'Please Enter Document')]") WebElement saveBtnMsg;

	//select page dropdown
	@FindBy(how = How.ID, using = "ddlSelectpage") WebElement selectPage;

	//cross button in select drop down page

	@FindBy(how = How.ID, using = "DeleteSigners_1") WebElement crossSign;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Atleast one signatory')]") WebElement signatryMsg;

	//doc successfully created
	@FindBy(how = How.ID, using = "objpdfconfigviewmodel_Profile") WebElement docName;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Congrats! Document template')]") WebElement docCreated;
	//browse doc page	
	@FindBy(how = How.ID, using = "frmSign") WebElement browseDocPage;
	//browse doc continue btn  
	@FindBy(how = How.ID, using = "btncontinuenext") WebElement browseContinueBtn;
	@FindBy(how = How.XPATH, using = "//div[text()='Please select Source']") WebElement browseContinueMsg;
	
	//source folder
	@FindBy(how = How.ID, using = "btnsource") WebElement sourceFolder;
	@FindBy(how = How.XPATH, using = "//div[text()='Please select Destination']") WebElement sourceContinueMsg;
	
	//dest Folder
	@FindBy(how = How.ID, using = "btnDest") WebElement destFolder;
	
	
	public pf_BulkDocument(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}


	public void bulkSigning(String sheetName, String scriptname) throws Exception {
		cl_click(bulkDoc);
		Thread.sleep(3000);
		cl_click(continuebutton);
		String msg= continueMsg.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);

	}

	public void uploadNonPDF(String path, String sheetName, String scriptname) throws Exception {
		cl_entertext(createTempbutton,path);
		String uploadMsg=uploadMessage.getText();
		Utility.comparelogic(uploadMsg,sheetName,scriptname);
		cl_click(okBtn);

	}

	public void uploadPDF(String pdfpath, String sheetName, String scriptname) throws Exception {
		cl_entertext(createTempbutton,pdfpath);
		Thread.sleep(10000);
		Boolean b=progressMsg.isDisplayed();
		System.out.println("progress bar displayed: "+b);
		if(b == false) {
			Basefunctions.getScreenshot();
			Assert.fail();
		}
		Thread.sleep(30000);		

		cl_click(saveBtn);
		String saveMsg=saveBtnMsg.getText();
		Utility.comparelogic(saveMsg,sheetName,scriptname);
		cl_click(okBtn);

	}

	public void verifySelectPage(String sheetName, String scriptname) throws Exception {
		Select slctPge=new Select(selectPage);
		slctPge.selectByIndex(6);
		cl_click(crossSign);
		String msg=signatryMsg.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);

	}


	public void uploadDocument() throws Exception {
		String name=Utility.getpropertydetails("bulkdocTemplateName");
		System.out.println("name: "+name);
		cl_entertext(docName,name);
		cl_click(saveBtn);		
		String exp="Congrats! Document template "+name+" has been successfully created";
		System.out.println("docCreationMsg"+exp);
		cl_click(okBtn);

	}


	public void browseDocIsDisplayed() throws Exception {
		if(browseDocPage.isDisplayed()) {
			System.out.println("Browse documents is displayed");
		}else {
			Basefunctions.getScreenshot();
			Assert.fail();			
		}

	}


	public void browseContinue(String sheetName, String scriptname) throws Exception {
		Thread.sleep(2000);
		cl_click(browseContinueBtn);	
		String browseCtnMsg=browseContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseCtnMsg,sheetName,scriptname);
		
	}


	public void browseSourceContinue(String sheetName, String scriptname) throws Exception {
		cl_click(sourceFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\destFolder\\destfolder.exe");
		Thread.sleep(8000);
		cl_click(browseContinueBtn);	
		String browseCMsg=sourceContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseCMsg,sheetName,scriptname);
		Thread.sleep(2000);
		cl_click(destFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\destFolder\\destfolder.exe");
		Thread.sleep(8000);
		cl_click(browseContinueBtn);	
	}


}
