package Page_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Generic_Library.Utility;

public class pf_DocstorePage extends pf_genericmethods {
	
	@FindBy(how = How.XPATH, using = "//span[text()='Doc store']") WebElement docStore;
	//title
	@FindBy(how = How.XPATH, using = "//*[text()='Document Store']") WebElement docStoreTitle;
	//upload Document
	
	@FindBy(how = How.XPATH, using = "//a[text()='Upload Document']") WebElement uploadDocBtn; 
	
	@FindBy(how = How.ID, using = "treetag") WebElement BrowseCategory;
	@FindBy(how = How.XPATH, using = "//div[@class='modal-content']") WebElement BrowseCategoryPopup;
	
	@FindBy(how = How.ID, using = "searchid") WebElement popupSearch;
	@FindBy(how = How.XPATH, using = "//button[@class='close']") WebElement closeBtn;
	
	public pf_DocstorePage(WebDriver driver){

		PageFactory.initElements(driver, this);
	}




	public void clickDocstore() {
		cl_click(docStore);
		System.out.println("Title Document Store is displayed: "+docStoreTitle.isDisplayed());
	}




	public void uploadDocument() throws Exception {
		
		cl_click(uploadDocBtn);
		cl_click(BrowseCategory);
		Thread.sleep(3000);
		System.out.println("Popup is displayed: "+BrowseCategoryPopup.isDisplayed());
		//Thread.sleep(3000);
		String workflowName=Utility.getpropertydetails("SearchWorkflow");
		cl_entertext(popupSearch, workflowName);
		cl_click(closeBtn);
	}
}
