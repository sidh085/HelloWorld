package Page_Factory;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.thoughtworks.selenium.webdriven.commands.GetValue;

import Generic_Library.Utility;
import javafx.scene.control.DatePicker;

public class pf_Settings extends pf_genericmethods {

	@FindBy(how = How.XPATH, using = "//i[@class='fa fa-user icon-xs icon-rounded']") public WebElement username;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Settings']") public WebElement settings;
	
	//My Profile  
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmappSettings\"]/div/div[3]/div[1]/a") public WebElement myProfile;
	//save button	
	@FindBy(how = How.ID, using = "btnUpdate") public WebElement saveBtn;
	//Save button message	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'User details')]") public WebElement saveBtnMsg;
	//ok button
	@FindBy(how = How.ID, using = "btnmsgok") WebElement okBtn; 
	//back button
	@FindBy(how = How.ID, using = "btncanceld") WebElement cancelBtn; 
	
	//mandatory fields 
	//Name
	@FindBy(how = How.ID, using = "Name") WebElement name;
	//Organization
	@FindBy(how = How.ID, using = "Organization") WebElement organization;
	//Designation
	@FindBy(how = How.ID, using = "Designation") WebElement designation;
	//Contact_Number
	@FindBy(how = How.ID, using = "Contact_Number") WebElement contact_Number;
	//address-country
	@FindBy(how = How.ID, using = "address-country") WebElement addressCountry;
	//Email
	@FindBy(how = How.ID, using = "Email_Id") WebElement emailIdTxtBox;
	
	//port settings	
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmappSettings\"]/div/div[3]/div[3]/a") public WebElement portSettings;
	@FindBy(how = How.ID, using = "txtdefaultport") WebElement portNumber;
	//change port number
	@FindBy(how = How.ID, using = "txtPortNumber") WebElement changePortNumber;
	//update Btn
	@FindBy(how = How.ID, using = "btnTest") WebElement updateBtn;
	//update btn without entering change port number
	@FindBy(how = How.XPATH, using = "//div[text()='Please enter port number']") public WebElement blnkUpdateMsg;
	//update btn by entering change port number
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'emSigner service')]") public WebElement UpdateMsg;
	//success message
	@FindBy(how = How.XPATH, using = "//div[text()='Port number updated successfully']") public WebElement successMsg;
	
	//back button from port settings to settings page
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmsettings\"]/div[1]/div/h1/a/i") public WebElement portBackBtn;
	
	// Manage AUTHToken
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmappSettings\"]/div/div[3]/div[4]/a") public WebElement manageAuthToken;
	@FindBy(how = How.ID, using = "btngenerateAuthtoken") WebElement generateAuthToken;
	@FindBy(how = How.XPATH, using = "//*[@id=\"1\"]/td[2]") public WebElement authToken;
	@FindBy(how = How.XPATH, using = "//*[@id=\"1\"]/td[3]") public WebElement createdBy;
	@FindBy(how = How.XPATH, using = "//*[@id=\\\"1\\\"]/td[4]") public WebElement datetime;
	//delete Authtoken
	//@FindBy(how = How.ID, using = "lnkDelete") WebElement deleteAuthToken;	
	@FindBy(how = How.XPATH, using = "//*[@id=\"lnkDelete\"]/i") WebElement deleteAuthToken;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Are you sure')]") public WebElement deleteTokenMsg;
	//back button from manage Authtoken to settings page
	@FindBy(how = How.XPATH, using = "//*[@id=\"main-content\"]/section/form/div[1]/div/h1/a/i") public WebElement manageTtBackBtn;
	
	
	// Auto Delegate	
	@FindBy(how = How.XPATH, using = "//*[@id=\"frmappSettings\"]/div/div[3]/div[5]/a") public WebElement autoDelegate;
	@FindBy(how = How.ID, using = "btnCreate") WebElement createDelegate;
	@FindBy(how = How.ID, using = "EmailID") WebElement emailID; 
	@FindBy(how = How.ID, using = "DelegateName") WebElement DelegateName;
	@FindBy(how = How.ID, using = "DelegateStartDate") WebElement DelegateStartDate;
	@FindBy(how = How.ID, using = "DelegateEndDate") WebElement DelegateEndDate;	
	@FindBy(how = How.ID, using = "Reason") WebElement Reason;
	@FindBy(how = How.ID, using = "btnSave") WebElement saveBtnAutoD;
	//back button from auto delegate to settings page
	@FindBy(how = How.XPATH, using = "//*[@id=\"main-content\"]/section/div[1]/div/div/h1/a/i") public WebElement autoDBackBtn;
	
	public pf_Settings(WebDriver driver){

		PageFactory.initElements(driver, this);
	}


	public void settings() throws Exception {
		cl_click(username);
		cl_click(settings);
		Thread.sleep(1000);
//		cl_click(myProfile);
//		Thread.sleep(1000);
	}


	public void myProfileNoEdit(String scriptname, String sheetName) throws Exception {
		cl_click(myProfile);
		Thread.sleep(2000);
		System.out.println("Name is: "+name.getAttribute("value"));
		System.out.println("Organization is: "+organization.getAttribute("value"));
		System.out.println("Designation is: "+designation.getAttribute("value"));
		System.out.println("Contact_Number is: "+contact_Number.getAttribute("value"));
		//System.out.println("AddressCountry is: "+addressCountry.getAttribute("value"));
		System.out.println("Email is: "+emailIdTxtBox.getAttribute("value"));
		System.out.println("Email Field is enabled: "+emailIdTxtBox.isEnabled());
		cl_click(saveBtn);
		String msg=saveBtnMsg.getText();
		Utility.comparelogic(msg, sheetName, scriptname);
		cl_click(okBtn);
		
	}


	public void myProfilecnclBtn(String scriptname, String sheetName) throws Exception {
		cl_click(myProfile);
		Thread.sleep(1000);
		cl_click(cancelBtn);
		String url=w.getCurrentUrl();
		Utility.comparelogic(url,sheetName,scriptname);
		
	}


	public void portblankUpdateBtn(String scriptname, String sheetName) throws Exception {
		cl_click(portSettings);
		System.out.println("Port number is: "+portNumber.getAttribute("value"));
		cl_click(updateBtn);
		String msg=blnkUpdateMsg.getText();
		Utility.comparelogic(msg, sheetName, scriptname);
		cl_click(okBtn);
	}


	public void portUpdateBtn(String scriptname, String sheetName) throws Exception {
		String portNumber=Utility.getpropertydetails("portNumber");
		cl_entertext(changePortNumber, portNumber);
		cl_click(updateBtn);
		String msg=UpdateMsg.getText();
		Utility.comparelogic(msg, sheetName, scriptname);	
	}


	public void portUpdateBtnsuccess(String scriptname, String sheetName) throws Exception {
		cl_click(okBtn);
		String msg=successMsg.getText();
		Utility.comparelogic(msg, sheetName, scriptname);	
		cl_click(okBtn);
		cl_click(portBackBtn);
		Thread.sleep(2000);
	}


	public void generateToken() throws Exception {
		cl_click(manageAuthToken);
		Thread.sleep(2000);
		cl_click(generateAuthToken);
		Thread.sleep(4000);
		System.out.println("created AuthToken is: "+authToken.getText());
		System.out.println("created By: "+createdBy.getText());
	}


	public void deleteAuthToken(String scriptname, String sheetName) throws Exception {		
		cl_click(deleteAuthToken);	
		String msg=deleteTokenMsg.getText();
		Utility.comparelogic(msg, sheetName, scriptname);	
		cl_click(okBtn);
		Thread.sleep(2000);
		cl_click(manageTtBackBtn);
		Thread.sleep(2000);
	}


	public void createAutoD() throws Exception {
		cl_click(autoDelegate);
		Thread.sleep(1000);
		cl_click(createDelegate);
		cl_click(cancelBtn);
		Thread.sleep(1000);
		
		/*cl_click(createDelegate);
		String email=Utility.getpropertydetails("AutoDelegateEmailID");
		cl_entertext(emailID, email);
		String name=Utility.getpropertydetails("AutoDelegateName");
		cl_entertext(DelegateName, name);
		String startDate=Utility.getpropertydetails("AutoDelegateStartDate");		
		cl_entertext(DelegateStartDate, startDate);
		String endDate=Utility.getpropertydetails("AutoDelegateEndDate");
		cl_entertext(DelegateStartDate, endDate);
		String reason=Utility.getpropertydetails("AutoDelegateReason");
		cl_entertext(Reason, reason);
		cl_click(saveBtnAutoD);*/
		cl_click(autoDBackBtn);
		Thread.sleep(1000);
	}


	

}
