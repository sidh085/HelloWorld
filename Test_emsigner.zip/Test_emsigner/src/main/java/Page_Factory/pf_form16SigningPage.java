package Page_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import Generic_Library.Basefunctions;
import Generic_Library.Utility;

public class pf_form16SigningPage extends pf_genericmethods {

	@FindBy(how = How.XPATH, using = "//*[text()='Form16 Signing']") WebElement form16Signing;
	@FindBy(how = How.ID, using = "step1Content") WebElement templtePage;
	@FindBy(how = How.ID, using = "btncontinue") WebElement continuebutton;
	@FindBy(how = How.XPATH, using = "//div[@class='info']") WebElement continueMsg;
	@FindBy(how = How.ID, using = "btnpdfupload") WebElement createTempbutton;
	//message while uploading doc other than pdf
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'NOTE:Only .PDF document(s)')]") WebElement uploadMessage;
	@FindBy(how = How.ID, using = "btnmsgok") WebElement okBtn;
	//check progress bar
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Preparing your document for')]") WebElement progressMsg;
	//check template setting
	@FindBy(how = How.CLASS_NAME, using = "box") WebElement tmplteSettingBox;
	//save button
	@FindBy(how = How.ID, using = "btnSave") WebElement saveBtn;
	@FindBy(how = How.XPATH, using ="//div[contains(text(),'Please Enter Document')]") WebElement saveBtnMsg;
	//select page dropdown
	@FindBy(how = How.ID, using = "ddlSelectpage") WebElement selectPage;

	//cross button in select drop down page

	@FindBy(how = How.ID, using = "DeleteSigners_1") WebElement crossSign;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Atleast one signatory')]") WebElement signatryMsg;

	//doc successfully created
	@FindBy(how = How.ID, using = "objpdfconfigviewmodel_Profile") WebElement docName;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Congrats! Document template')]") WebElement docCreated;	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Sorry!Template name')]") WebElement templateExist;
	
	//browse doc page	
	@FindBy(how = How.XPATH, using = "//div[@class='row form-page top15']") WebElement browseDocPage;

	//browse doc continue btn  
	@FindBy(how = How.ID, using = "btncontinuenext") WebElement browseContinueBtn;
	@FindBy(how = How.XPATH, using = "//div[text()='Please select PartA Folder.']") WebElement browseContinueMsg;
	@FindBy(how = How.XPATH, using = "//div[text()='Please select PartB Folder.']") WebElement browseAContinueMsg;
	@FindBy(how = How.XPATH, using = "//div[text()='Please select destination folder']") WebElement browseABContinueMsg;
	@FindBy(how = How.XPATH, using = "//div[text()='Please upload CSV file format.']") WebElement browseABDContinueMsg;

	//part A folder
	@FindBy(how = How.ID, using = "btnFormA") WebElement partAFolder;
	//part B folder
	@FindBy(how = How.ID, using = "btnFormB") WebElement partBFolder;
	//Dest folder
	@FindBy(how = How.ID, using = "btnDest") WebElement destFolder;
	//csv folder
	@FindBy(how = How.ID, using = "btnfile") WebElement csvFolder;
	//doc setting page	
	@FindBy(how = How.ID, using = "step3Content") WebElement docSetngPage;
	@FindBy(how = How.ID, using = "btnProcess") WebElement continueProcess;	
	@FindBy(how = How.ID, using = "btncancel") WebElement cancelBtn;

	//emailing option 	
	@FindBy(how = How.ID, using = "sendEmail") WebElement chckbxSndMail;
	@FindBy(how = How.ID, using = "rdemudhraconfig") WebElement rBtnemSignerSMTP;
	@FindBy(how = How.ID, using = "rdotherconfig") WebElement rBtnOtherSMTP;	
	@FindBy(how = How.XPATH, using = "//div[text()='Please enter Email Address']") WebElement processContinueMsg;
	@FindBy(how = How.ID, using = "From") WebElement fromAddress;
	@FindBy(how = How.ID, using = "Subject") WebElement subject;

	public pf_form16SigningPage(WebDriver driver){

		PageFactory.initElements(driver, this);
	}

	public void form16Signing(String sheetName,String scriptname) throws Exception{
		cl_click(form16Signing);
		Thread.sleep(3000);
		cl_click(continuebutton);
		String msg= continueMsg.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);
	}

	public void uploadPDF(String path,String sheetName, String scriptname) throws Exception {
		cl_entertext(createTempbutton,path);
		Thread.sleep(10000);
		Boolean b=progressMsg.isDisplayed();
		System.out.println("progress bar displayed: "+b);
		if(b == false) {
			Basefunctions.getScreenshot();
			Assert.fail();
		}
		Thread.sleep(30000);		
//		Boolean b1=tmplteSettingBox.isDisplayed();
//		System.out.println("template setting page displayed: "+b1);
//		if(b1 == false) {
//			Basefunctions.getScreenshot();
//			Assert.fail();
//		}
		cl_click(saveBtn);
		String saveMsg=saveBtnMsg.getText();
		Utility.comparelogic(saveMsg,sheetName,scriptname);
		cl_click(okBtn);
	}

	public void uploadNonPDF(String path,String sheetName,String scriptname) throws Exception {
		cl_entertext(createTempbutton,path);
		String uploadMsg=uploadMessage.getText();
		Utility.comparelogic(uploadMsg,sheetName,scriptname);
		cl_click(okBtn);
	}

	public void verifySelectPage(String sheetName,String scriptname) throws Exception {
		Select slctPge=new Select(selectPage);
		slctPge.selectByIndex(6);
		cl_click(crossSign);
		String msg=signatryMsg.getText();
		Utility.comparelogic(msg,sheetName,scriptname);
		cl_click(okBtn);
	}

	public void uploadDocument() throws Exception {
		String name=Utility.getpropertydetails("docTemplateName");
		System.out.println("name: "+name);
		cl_entertext(docName,name);
		cl_click(saveBtn);		
		String exp="Congrats! Document template "+name+" has been successfully created";
		System.out.println("docCreationMsg"+exp);
		cl_click(okBtn);		
//		String msg="Sorry!Template name "+name+" already exists. Please try again with a different name";
//		System.out.println("templateExistMsg"+msg);
//		Basefunctions.getScreenshot();
//		cl_click(okBtn);
		
	}

	public void browseDocIsDisplayed() throws Exception {
		if(browseDocPage.isDisplayed()) {
		System.out.println("Browse documents is displayed");
		}else {
			Basefunctions.getScreenshot();
			Assert.fail();			
		}
	}

	public void browseContinue(String sheetName,String scriptname) throws Exception {
		cl_click(browseContinueBtn);	
		String browseCtnMsg=browseContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseCtnMsg,sheetName,scriptname);
	}
	
	public void browseAContinue(String sheetName,String scriptname) throws Exception {
		cl_click(partAFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\partAFolder\\new.exe");
		Thread.sleep(8000);
		cl_click(browseContinueBtn);	
		String browseCMsg=browseAContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseCMsg,sheetName,scriptname);
	}
	
	public void browseABContinue(String sheetName,String scriptname) throws Exception {
		cl_click(partBFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\partBFolder\\new.exe");
		Thread.sleep(6000);
		cl_click(browseContinueBtn);	
		String browseABMsg=browseABContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseABMsg,sheetName,scriptname);
	}
	
	public void browseABDestContinue(String sheetName,String scriptname) throws Exception {
		cl_click(destFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\destFolder\\destfolder.exe");
		Thread.sleep(6000);
		cl_click(browseContinueBtn);	
		String browseDCMsg=browseABDContinueMsg.getText();
		cl_click(okBtn);
		Utility.comparelogic(browseDCMsg,sheetName,scriptname);
		Thread.sleep(2000);
		cl_click(csvFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\csvFolder\\csvFile.exe");
		Thread.sleep(7000);
		cl_click(browseContinueBtn);
		//System.out.println("doc setting page is displayed: "+docSetngPage.isDisplayed());
		if(docSetngPage.isDisplayed() == true) {
			System.out.println("doc setting page is displayed");
		}
		else {
			Basefunctions.getScreenshot();
			Assert.fail();
		}
		
	}
	
	public void browseABDCSVContinue(String sheetName,String scriptname) throws Exception {
		cl_click(csvFolder);
		Runtime.getRuntime().exec("D:\\sindhu\\HPEdrive\\Selenium Scripts\\autoit scripts\\csvFolder\\csvFile.exe");
		Thread.sleep(7000);
		cl_click(browseContinueBtn);
		//System.out.println("doc setting page is displayed: "+docSetngPage.isDisplayed());
		if(docSetngPage.isDisplayed() == true) {
			System.out.println("doc setting page is displayed");
		}
		else {
			Basefunctions.getScreenshot();
			Assert.fail();
		}
		//		cl_click(cancelBtn);		
		//		System.out.println("redirect to choose template page: "+templtePage.isDisplayed());		
		//		cl_click(continueProcess);		
	}

	/*public void verifyemSignerSMTP(String fromAdd, String sbjct,String sheetName) throws Exception {
		cl_click(chckbxSndMail);

		if(!rBtnemSignerSMTP.isSelected()) {
			cl_click(rBtnemSignerSMTP);
			cl_click(continueProcess);
			String msg= processContinueMsg.getText();
			cl_click(okBtn);
			Utility.comparelogic(msg,sheetName);

			cl_entertext(fromAddress, fromAdd);
			cl_entertext(subject, sbjct);
			cl_click(continueProcess);
			String msg1= processContinueMsg.getText();		
			cl_click(okBtn);
			Utility.comparelogic(msg1,sheetName);
		}
	}

	public void verifyOtherSMTP(String sbjct,String sheetName) throws Exception {

		if(!rBtnOtherSMTP.isSelected()) {
			cl_click(rBtnOtherSMTP);
			cl_click(continueProcess);
			String msg= processContinueMsg.getText();	
			Utility.comparelogic(msg,sheetName);
			cl_click(okBtn);

			cl_entertext(subject, sbjct);
			cl_click(continueProcess);
			String msg1= processContinueMsg.getText();	
			Utility.comparelogic(msg1,sheetName);
			cl_click(okBtn);
		}
	}*/

	public void form16Sign() {
		cl_click(form16Signing);		
	}
}
