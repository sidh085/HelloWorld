package Scripts;

import java.util.Map;

import org.testng.annotations.Test;

import Generic_Library.Basefunctions;
import Page_Factory.pf_DocstorePage;
import Page_Factory.pf_loginpage;

public class Docstore_Script extends Basefunctions {
	@Test(dataProvider= "valid_login",dataProviderClass=Dataproviders.dp_login.class,enabled=true,priority=1,groups={"SMK","REG"})
	public static void Form16Sign(Map hm) throws Exception{		
		//login
	
		String uid = hm.get("Uname").toString();
		String pas = hm.get("Pwd").toString();
		pf_loginpage pl = new pf_loginpage(w);
		pl.logincredentials(uid, pas );
	}
	@Test(priority=2,groups={"SMK","REG"})
	public static void docStore() throws Exception{	
		
		pf_DocstorePage docstore=new pf_DocstorePage(w);
		docstore.clickDocstore();
		
		docstore.uploadDocument();
	}
}
